<?php include 'common/header.php';?>
<?php include 'common/left.php';?>


<!-- SLIDER -->
<section class="rev_slider_wrapper">
	<div id="rev_slider_3" class="rev_slider">

		<div class="row" style="margin-top: 182px;">
			<div class="col-xs-3"></div>
			<div class="col-xs-2" style="text-align: left; z-index: 1;">
				<!--<img  src="images/notifications.png" style="width:100%;" alt="logo">
-->
			</div>


			<div class="col-xs-7" style="text-align: right; z-index: 1;">
				<!--<img  src="images/services.png" style="width:20%;" alt="logo"> 
-->

			</div>
			<div class="row">
				<div class="col-md-12" style="z-index: 1">
					<div class="row">
						<div class="col-xs-6" style="text-align: Center">
							<h3>Notifications</h3>
						</div>
						<div class="col-xs-6" style="text-align: Center">
							<h3>Services</h3>
						</div>

					</div>

				</div>
			</div>

			<div class="row">
				<div class="col-md-2"></div>
				<div class="col-md-8">
					<img style="width: 100%;" src="<?php echo base_url("assets")?>/images/conbridlogo.jpg" alt=""
						data-bgposition="center center" data-bgfit="cover"
						class="rev-slidebg">
				</div>
			</div>
		</div>
	</div>
</section>
<!--SLIDER -->



<!-- TEAM -->
<section id="team-sev" class="padding bg_light" style="">
	<div class="row">


		<div class="col-md-12" style="margin-top: 140px;">

			<br>
			<h2 class="text-uppercase">
				become a <span class="color_red">Conbrid challenge member</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input
					type="button" class="btn_fill" value="Refer">
			</h2>


		</div>
	</div>



</section>


<section id="team-sev" class="padding bg_light"
	style="padding: 0px !important;">
	<div class="row">


		<div class="col-md-12">

			<br>
			<h2 class="text-uppercase">
				Become a <span class="color_red"> Member</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input
					type="button" class="btn_fill" value="Refer">
			</h2>



		</div>
	</div>



</section>
<br>
<br>
<br>
<!--TEAM -->



<div class="row">
	<div class="col-md-12">

		<!-- CONTACT -->
		<section id="contact" class="bg-color-red">
			<div class="container" style="width: 100% !important;">
				<div class="row">
					<div class="col-md-4 col-sm-4 col-xs-12 text-center">
						<div class="get-tuch">
							<i class="icon-telephone114"></i>
							<ul>
								<li>
									<h4>Phone Number</h4>
								</li>
								<li>
									<p>+1 900 234 567 - 68</p>
								</li>
							</ul>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-12 text-center">
						<div class="get-tuch">
							<i class="icon-icons74"></i>
							<ul>
								<li><h4>Victoria Hall,</h4></li>
								<li><p>Idea Homes, australia</p></li>
							</ul>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-12 text-center">
						<div class="get-tuch">
							<i class=" icon-icons142"></i>
							<ul>
								<li><h4>Email Address</h4></li>
								<li><a href="#.">info@ideahomes.com</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- CONTACT -->

										<?php include 'common/footer.php';?>