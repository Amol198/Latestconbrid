
<section id="team-sev" class="padding bg_light"
	style="margin-top: 157px;">

	<h5 style="text-align: center;">Sorry. Your account is not activated by admin yet. Please contact Administration for this</h5>
<br>	<h5 style="text-align: center;"><a class="btn btn-info" href="<?php echo base_url("Dashboard")?>">Go to Dashboard</a></h5><br>
</section>