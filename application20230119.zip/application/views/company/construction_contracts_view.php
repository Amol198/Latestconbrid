<style>
sup {
	color: red;
}

.checked {
	color: orange;
}
</style>
<section id="team-sev" class="padding bg_light"
	style="margin-top: 157px;">

	<h1 style="text-align: center;">Construction Contract</h1>
	<div class="row"
		style="background: white; height: 400px; margin: 20px;">
		<br>
		<br>
		<div class="col-md-1">&nbsp;</div>
		<div class="col-md-2 col-xs-4">
			<label>3 Star Ratings</label><br>
			<br>
			<br>
			<span class="fa fa-star checked"></span> <span
				class="fa fa-star checked"></span> <span class="fa fa-star checked"></span>
			<span class="fa fa-star"></span> <span class="fa fa-star"></span>
		</div>
		<div class="col-md-2 col-xs-4">
			<label>View Details</label><br> <img style="width: 100px;"
				src="<?php echo base_url("assets/images/starimage.png")?>">
		</div>
		<div class="col-md-2 col-xs-4">
			<label>Call</label><br> <img style="width: 100px;"
				src="<?php echo base_url("assets/images/callicon.png")?>">
		</div>
		<div class="col-md-2 col-xs-4">
			<label>Message</label><br> <img style="width: 100px;"
				src="<?php echo base_url("assets/images/messageicon.png")?>">
		</div>
		<div class="col-md-2 col-xs-4">
			<label>Glowing Lead</label><br> <img style="width: 100px;"
				src="<?php echo base_url("assets/images/circle-glowing.gif")?>">
		</div>
		<div class="col-md-1">&nbsp;</div>

	</div>
	<br>
</section>
<script
	src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
$('.select2').select2();

</script>

