<?php include 'common/header.php';?>
<?php include 'common/left.php';?>

<style>
.glyphicon-arrow-down{
font-size: 100px;}
</style>

<section id="team-sev" class="padding bg_light"
	style="margin-top: 157px;">
	<div class="row">


		<div class="col-md-12" style="text-align:center!important;">
			<h2 class="text-uppercase">
				Conbrid<span class="color_red"> Challenge Members</span>
				
			</h2>
			<br><br>
			 <h4 id="hours" style="color:red;"></h4><br><br>
<div class="row">
    <div class="col-md-4">&nbsp;</div>
        <div align="center" class="col-md-4" style="text-align:center;"><div style="width:100%;height:150px; box-shadow: 0px 0px 16px 6px grey; background: #ce4545;"><br><h2 style="color:white;">1 Customer</h2>
        <br><button type="button" class="btn btn-primary" data-toggle="modal" onclick="add_copy_link('<?php echo base64_encode('Customer')?>','<?php echo base64_encode($_SESSION['userdata']['promo_code'])?>')" data-target="#exampleModal">
  Refer
</button>
        </div></div>
            
<div class="col-md-4">&nbsp;</div></div>
<div class="row">
<div class="col-md-4">&nbsp;</div>
        <div align="center" class="col-md-4" style="text-align:center;"><img style="height:100px;" src="<?php echo base_url("assets/images/and-arrow.png");?>"></div>
        
<div class="col-md-4">&nbsp;</div>        
        </div>
<div class="row">
    <div class="col-md-4">&nbsp;</div>
        <div align="center" class="col-md-4" style="text-align:center;"><div style="width:100%;height:150px; box-shadow: 0px 0px 16px 6px grey; background: #ce4545;"><br><h2 style="color:white;">1 Builder and developer company</h2>
              <br><button type="button" class="btn btn-primary" data-toggle="modal" onclick="add_copy_link('<?php echo base64_encode('Builder and developer company')?>','<?php echo base64_encode($_SESSION['userdata']['promo_code'])?>')" data-target="#exampleModal">
  Refer
</button>
  
        </div></div>
            
<div class="col-md-4">&nbsp;</div></div>
<div class="row">
<div class="col-md-4">&nbsp;</div>
        <div align="center" class="col-md-4" style="text-align:center;"><img style="height:100px;" src="<?php echo base_url("assets/images/and-arrow.png");?>"></div>
        
<div class="col-md-4">&nbsp;</div>        
        </div>
<div class="row">
    <div class="col-md-4">&nbsp;</div>
        <div align="center" class="col-md-4" style="text-align:center;"><div style="width:100%;height:150px; box-shadow: 0px 0px 16px 6px grey; background: #ce4545;"><br><h2 style="color:white;">1 Civil contractor company</h2>
              <br><button type="button" class="btn btn-primary" data-toggle="modal" onclick="add_copy_link('<?php echo base64_encode('Civil contractor company')?>','<?php echo base64_encode($_SESSION['userdata']['promo_code'])?>')" data-target="#exampleModal">
  Refer
</button>
 
        </div></div>
            
<div class="col-md-4">&nbsp;</div></div>
<div class="row">
<div class="col-md-4">&nbsp;</div>
        <div align="center" class="col-md-4" style="text-align:center;"><img style="height:100px;" src="<?php echo base_url("assets/images/and-arrow.png");?>"></div>
        
<div class="col-md-4">&nbsp;</div>        
        </div>
     <div class="row">
    <div class="col-md-4">&nbsp;</div>
        <div align="center" class="col-md-4" style="text-align:center;"><div style="width:100%;height:150px; box-shadow: 0px 0px 16px 6px grey; background: #ce4545;"><br><h2 style="color:white;">1 Civil engineering company</h2>
              <br><button type="button" class="btn btn-primary" data-toggle="modal" onclick="add_copy_link('<?php echo base64_encode('Civil engineering company')?>','<?php echo base64_encode($_SESSION['userdata']['promo_code'])?>')" data-target="#exampleModal">
  Refer
</button>
 
        </div></div>
            
<div class="col-md-4">&nbsp;</div></div>
<div class="row">
<div class="col-md-4">&nbsp;</div>
        <div align="center" class="col-md-4" style="text-align:center;"><img style="height:100px;" src="<?php echo base_url("assets/images/and-arrow.png");?>"></div>
        
<div class="col-md-4">&nbsp;</div>        
        </div>
<div class="row">
    <div class="col-md-4">&nbsp;</div>
        <div align="center" class="col-md-4" style="text-align:center;"><div style="width:100%;height:150px; box-shadow: 0px 0px 16px 6px grey; background: #ce4545;"><br><h2 style="color:white;">1 Project management company</h2>
               <br><button type="button" class="btn btn-primary" data-toggle="modal" onclick="add_copy_link('<?php echo base64_encode('Project management company')?>','<?php echo base64_encode($_SESSION['userdata']['promo_code'])?>')" data-target="#exampleModal">
  Refer
</button>
 
        </div></div>
            
<div class="col-md-4">&nbsp;</div></div>
<div class="row">
<div class="col-md-4">&nbsp;</div>
        <div align="center" class="col-md-4" style="text-align:center;"><img style="height:100px;" src="<?php echo base_url("assets/images/and-arrow.png");?>"></div>
        
<div class="col-md-4">&nbsp;</div>        
        </div>
<div class="row">
    <div class="col-md-4">&nbsp;</div>
        <div align="center" class="col-md-4" style="text-align:center;"><div style="width:100%;height:150px; box-shadow: 0px 0px 16px 6px grey; background: #ce4545;"><br><h2 style="color:white;">1 Architectural company</h2>
               <br><button type="button" class="btn btn-primary" data-toggle="modal" onclick="add_copy_link('<?php echo base64_encode('Architectural company')?>','<?php echo base64_encode($_SESSION['userdata']['promo_code'])?>')" data-target="#exampleModal">
  Refer
</button>
 
        </div></div>
            
<div class="col-md-4">&nbsp;</div></div>
<div class="row">
<div class="col-md-4">&nbsp;</div>
        <div align="center" class="col-md-4" style="text-align:center;"><img style="height:100px;" src="<?php echo base_url("assets/images/and-arrow.png");?>"></div>
        
<div class="col-md-4">&nbsp;</div>        
        </div>
        <div class="row">
    <div class="col-md-4">&nbsp;</div>
        <div align="center" class="col-md-4" style="text-align:center;"><div style="width:100%;height:150px; box-shadow: 0px 0px 16px 6px grey; background: #ce4545;"><br><h2 style="color:white;">1 Individual Civil Engineer</h2>
              <br><button type="button" class="btn btn-primary" data-toggle="modal" onclick="add_copy_link('<?php echo base64_encode('Individual Civil Engineer')?>','<?php echo base64_encode($_SESSION['userdata']['promo_code'])?>')" data-target="#exampleModal">
  Refer
</button>
  
        </div></div>
            
<div class="col-md-4">&nbsp;</div></div>
<div class="row">
<div class="col-md-4">&nbsp;</div>
        <div align="center" class="col-md-4" style="text-align:center;"><img style="height:100px;" src="<?php echo base_url("assets/images/and-arrow.png");?>"></div>
        
<div class="col-md-4">&nbsp;</div>        
        </div>

<div class="row">
    <div class="col-md-4">&nbsp;</div>
        <div align="center" class="col-md-4" style="text-align:center;"><div style="width:100%;height:150px; box-shadow: 0px 0px 16px 6px grey; background: #ce4545;"><br><h2 style="color:white;">1 Individual project manager</h2>
              <br><button type="button" class="btn btn-primary" data-toggle="modal" onclick="add_copy_link('<?php echo base64_encode('Individual project manager')?>','<?php echo base64_encode($_SESSION['userdata']['promo_code'])?>')" data-target="#exampleModal">
  Refer
</button>
 
        </div></div>
            
<div class="col-md-4">&nbsp;</div></div>
<div class="row">
<div class="col-md-4">&nbsp;</div>
        <div align="center" class="col-md-4" style="text-align:center;"><img style="height:100px;" src="<?php echo base_url("assets/images/and-arrow.png");?>"></div>
        
<div class="col-md-4">&nbsp;</div>        
        </div>
<div class="row">
    <div class="col-md-4">&nbsp;</div>
        <div align="center" class="col-md-4" style="text-align:center;"><div style="width:100%;height:150px; box-shadow: 0px 0px 16px 6px grey; background: #ce4545;"><br><h2 style="color:white;">1 Individual architect</h2>
              <br><button type="button" class="btn btn-primary" data-toggle="modal" onclick="add_copy_link('<?php echo base64_encode('Individual architect')?>','<?php echo base64_encode($_SESSION['userdata']['promo_code'])?>')" data-target="#exampleModal">
  Refer
</button>
 
        </div></div>
            
<div class="col-md-4">&nbsp;</div></div>
<div class="row">
<div class="col-md-4">&nbsp;</div>
      
        
<div class="col-md-4">&nbsp;</div>        
        </div>
       

</div>

		</div>
	</div>



</section>




<div class="row">
	<div class="col-md-12">

		<!-- CONTACT -->
		<section id="contact" class="bg-color-red">
			<div class="container" style="width: 100% !important;">
				<div class="row">
					<div class="col-md-4 col-sm-4 col-xs-12 text-center">
						<div class="get-tuch">
							<i class="icon-telephone114"></i>
							<ul>
								<li>
									<h4>Phone Number</h4>
								</li>
								<li>
									<p>+1 900 234 567 - 68</p>
								</li>
							</ul>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-12 text-center">
						<div class="get-tuch">
							<i class="icon-icons74"></i>
							<ul>
								<li><h4>Victoria Hall,</h4></li>
								<li><p>Idea Homes, australia</p></li>
							</ul>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 col-xs-12 text-center">
						<div class="get-tuch">
							<i class=" icon-icons142"></i>
							<ul>
								<li><h4>Email Address</h4></li>
								<li><a href="#.">info@ideahomes.com</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- CONTACT -->
		<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <input type="text" class="form-control" readonly id="test_link">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" onclick="myFunction2()" class="btn btn-primary">Copy Link</button>
      </div>
    </div>
  </div>
</div>
<script>
    function add_copy_link(type,referee){
        
        $("#test_link").val("https://conbrid.unitglo.com/Dashboard/registration/"+type+"/"+referee);
    //    $("#test_link").val("https://conbrid.unitglo.com/Dashboard");
    }
    function myFunction2() {
  /* Get the text field */
  var copyText = document.getElementById("test_link");

  /* Select the text field */
  copyText.select();
  copyText.setSelectionRange(0, 99999); /* For mobile devices */

  /* Copy the text inside the text field */
  navigator.clipboard.writeText(copyText.value);
  
  /* Alert the copied text */
  alert("Link Copied");
}
</script>
										<?php include 'common/footer.php';?>